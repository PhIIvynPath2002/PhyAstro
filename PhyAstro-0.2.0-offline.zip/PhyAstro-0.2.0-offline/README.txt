PhyAstro v0.2.0 — Earth–Moon–Sun Observation System

打开
1. 解压此 ZIP 文件。
2. macOS：右键 PhyAstro-0.2.0.html > 打开方式 > Google Chrome。
   Windows：右键 PhyAstro-0.2.0.html > 打开方式 > Microsoft Edge。
3. 无须 npm、账户、服务器、CDN 或在线星历 API。HTML 可单独移动使用。
   请使用支持 WebGL 2 的近期版本浏览器，并启用图形加速。

初始状态
- 固定时间：2026-01-01 00:00:00 UTC。时间不会连续流逝。
- Observer：Earth Center。Target：Moon。
- 模式：Enhanced Visibility。科学调试面板默认展开。

空间观测
- 在科学调试面板中切换 Observer、Target、快照、显示时区和比例模式。
- 十字准星按钮：朝向目标。回转箭头：返回观测中心。四角按钮：系统全景。
- 拖动或滚轮可自由旋转；Shift + 滚轮横向旋转。
- Command（Mac）/ Ctrl（Windows）+ 滚轮或加减按钮可缩放。
- 默认箭头指针，按住拖动显示手掌；触屏支持拖动和双指缩放。
- 改变观测中心或目标不会删除其他天体。屏幕外、遮挡和小于一个像素的天体
  仍存在于场景中；可以选择目标并使用“朝向目标”查看其方向。

比例与数据
- Physical Scale：真实半径和真实距离采用同一单位换算。
- Enhanced Visibility：只增强显示半径，可能使远景中的球体重叠。
- 调试数据中的距离、相对向量和几何角直径均以 Observer Center 计算。
- Camera Position 是实际相机位置，两者明确分开。视野判断使用实际相机和
  当前渲染球体的视锥与基础遮挡测试。
- 科学参考系：太阳系质心原点、J2000 平赤道/平春分点轴（SSB / EQJ），单位 km。
- 星历：Astronomy Engine 2.1.19 的同一估计 TT 时刻几何位置。
- UTC、北京时间与纽约时间只改变显示；纽约夏令时由浏览器时区数据处理。
  月球民用时间未定义，本版不实现。

坐标仪兼容入口
- “天球坐标仪”保留 v0.1.3 的地球、地面、参考线、探针和双击信息功能。
- 坐标仪与空间系统会传递选定的 UTC 时刻。坐标仪仍保留原有低阶 Meeus 模型；
  它的方向球模型与 v0.2.0 的统一空间星历有明确区分，详见 docs/V0.2.0.md。
- 在空间系统中，地球参考线仅在 Earth Center 下显示，Sun/Moon 下会隐藏并说明。

验证与限制
- 82 项单元测试、23 项不同浏览器交互测试通过，离线构建零外部网络请求。
- 独立 NASA JPL 星历对照尚未完成：开发环境的网络代理以 403 阻止 Horizons。
  docs/validation 中保留请求、计算值、空参考值与未完成原因，未宣称精度已认证。
- 使用近似解析星历、估计 TT 与球形天体；无光行时、折射、月相、光照或食象模拟。
- 当前在 Linux Chromium 断网内嵌文档模式验证；云端禁止直接 file:// 导航，
  尚未在真实 macOS Chrome 或 Windows Edge 机器上测试本地双击打开。

文档
- CHANGELOG.md：v0.1.3 → v0.2.0 更新记录。
- docs/V0.2.0.md：架构、文件说明、科学定义、时间尺度与已知限制。
- docs/validation/v0.2.0-science.md / .json：四个快照及星历对照记录。
- docs/validation/v0.2.0-tests.md：自动化测试记录。
- docs/validation/offline-validation.json：离线导出验证结果。

本次交付停在 v0.2.0，等待实际 HTML 交互测试反馈。
