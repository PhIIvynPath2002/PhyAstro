PhyAstro 0.3.0 — Local Offline Prototype

打开 PhyAstro-0.3.0.html。macOS 使用近期 Chrome，Windows 使用近期 Edge。
不需要联网、账户、npm 或服务器；需要 WebGL 2 与图形加速。
ZIP 请先完整解压。source/ 仅供开发，普通使用无须打开或编译。

主视图：天球坐标仪 / 宇宙空间观测。天球与地面在坐标仪内部。
空间：选择中心与目标，近观目标可查看表面；重置回到观测中心。
滚轮上下旋转，Shift+滚轮横向旋转，Command/Ctrl+滚轮缩放。
严格太阳光下夜侧和全食月面为黑色；可选 3.5% 调试补光。
2026-03-03 三个快照用于检查半影/本影，不是接触时刻预测。
物理比例与增强显示不同，增强球体轮廓不是严格食象轮廓。
UI Lighting 是艺术反馈，不是科学测量。太阳表面是静态程序化示意。

docs/ 含模型、资源许可和验证记录。source/src/assets/source/ 含原始地图，
source/src/rendering/system/SurfaceMaterial.ts 含太阳纹理与表面着色源码。
图像衍生素材按 GPL-2.0-or-later 分发，保留原文件、许可及上游署名。
独立 JPL 精度对照尚未完成；真实 macOS/Windows 交互与性能仍需确认。
仅限三天体几何与渲染实验，不用于导航、精密指向或食象预报。
